create view accountOrderDataView as
(
select `voiceworks_core`.`accountOrderData`.`id`            AS `id`,
       `voiceworks_core`.`accountOrderData`.`accountId`     AS `accountId`,
       `voiceworks_core`.`accountOrderData`.`type`          AS `type`,
       `voiceworks_core`.`accountOrderData`.`value`         AS `value`,
       `voiceworks_core`.`accountOrderData`.`timestamp`     AS `timestamp`,
       `voiceworks_core`.`accountOrderData`.`period`        AS `period`,
       `voiceworks_core`.`accountOrderData`.`productTypeId` AS `productTypeId`,
       `voiceworks_core`.`accountOrderData`.`orderType`     AS `orderType`
from (`voiceworks_core`.`accountOrderData`
         left join `voiceworks_core`.`accountLastDateOrderView`
                   on ((((`accountLastDateOrderView`.`accountId` = `voiceworks_core`.`accountOrderData`.`accountId`) and
                         (`accountLastDateOrderView`.`timestamp` = `voiceworks_core`.`accountOrderData`.`timestamp`) and
                         (`accountLastDateOrderView`.`type` = `voiceworks_core`.`accountOrderData`.`type`)) or
                        isnull(`accountLastDateOrderView`.`accountId`)))));

