create definer = root@localhost trigger acl_process_role_deletes
    after delete
    on aclProcessRole
    for each row
BEGIN
  INSERT INTO service_synchronization_logs(urn, entityId) VALUES("urn:role:permission-updated", OLD.aclRoleId);
END;

