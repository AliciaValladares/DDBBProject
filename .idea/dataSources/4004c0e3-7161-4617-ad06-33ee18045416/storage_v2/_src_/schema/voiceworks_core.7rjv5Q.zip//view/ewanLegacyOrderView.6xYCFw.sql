create view ewanLegacyOrderView as
(select `voiceworks_core`.`ewanOrder`.`id`                                                                         AS `id`,
        'ewan'                                                                                                     AS `module`,
        `voiceworks_core`.`ewanOrder`.`id`                                                                         AS `ewanOrderId`,
        NULL                                                                                                       AS `dslOrderTiscaliId`,
        NULL                                                                                                       AS `dslOrderBbnedId`,
        `voiceworks_core`.`ewanOrder`.`ewanAccountId`                                                              AS `ewanAccountId`,
        NULL                                                                                                       AS `dslAccountId`,
        `voiceworks_core`.`ewanOrder`.`userId`                                                                     AS `userId`,
        if(isnull(`voiceworks_core`.`ewanOrder`.`ewanOrderStatusId`), 0,
           1)                                                                                                      AS `submitted`,
        `voiceworks_core`.`ewanAccount`.`ewanSupplierId`                                                           AS `ewanSupplierId`,
        `voiceworks_core`.`ewanAccount`.`accountId`                                                                AS `accountId`,
        ifnull(`voiceworks_core`.`ewanOrder`.`installAddressId`,
               `voiceworks_core`.`ewanOrder`.`requestAddressId`)                                                   AS `addressId`,
        `voiceworks_core`.`ewanOrder`.`created_at`                                                                 AS `created_at`,
        `voiceworks_core`.`ewanAccount`.`freeze`                                                                   AS `freeze`
 from (`voiceworks_core`.`ewanOrder`
          join `voiceworks_core`.`ewanAccount`
               on ((`voiceworks_core`.`ewanAccount`.`id` = `voiceworks_core`.`ewanOrder`.`ewanAccountId`))))
union
(select `voiceworks_core`.`dslOrderTiscali`.`id`                                                              AS `id`,
        'dsl'                                                                                                 AS `module`,
        NULL                                                                                                  AS `ewanOrderId`,
        `voiceworks_core`.`dslOrderTiscali`.`id`                                                              AS `dslOrderTiscaliId`,
        NULL                                                                                                  AS `dslOrderBbnedId`,
        NULL                                                                                                  AS `ewanAccountId`,
        `voiceworks_core`.`dslOrderTiscali`.`dslaccountId`                                                    AS `dslaccountId`,
        `voiceworks_core`.`dslAccount`.`userId`                                                               AS `userId`,
        `voiceworks_core`.`dslAccount`.`submitted`                                                            AS `submitted`,
        2                                                                                                     AS `ewanSupplierId`,
        `voiceworks_core`.`dslAccount`.`accountId`                                                            AS `accountId`,
        ifnull(`voiceworks_core`.`dslAccount`.`installAddressId`,
               `voiceworks_core`.`dslAccount`.`addressId`)                                                    AS `addressId`,
        `voiceworks_core`.`dslOrderTiscali`.`added`                                                           AS `created_at`,
        `voiceworks_core`.`dslAccount`.`freeze`                                                               AS `freeze`
 from (`voiceworks_core`.`dslOrderTiscali`
          join `voiceworks_core`.`dslAccount`
               on ((`voiceworks_core`.`dslAccount`.`id` = `voiceworks_core`.`dslOrderTiscali`.`dslaccountId`))))
union
(select `voiceworks_core`.`dslOrderBbned`.`id`                                                                AS `id`,
        'dsl'                                                                                                 AS `module`,
        NULL                                                                                                  AS `ewanOrderId`,
        NULL                                                                                                  AS `dslOrderTiscaliId`,
        `voiceworks_core`.`dslOrderBbned`.`id`                                                                AS `dslOrderBbnedId`,
        NULL                                                                                                  AS `ewanAccountId`,
        `voiceworks_core`.`dslOrderBbned`.`dslaccountId`                                                      AS `dslaccountId`,
        `voiceworks_core`.`dslAccount`.`userId`                                                               AS `userId`,
        `voiceworks_core`.`dslAccount`.`submitted`                                                            AS `submitted`,
        1                                                                                                     AS `ewanSupplierId`,
        `voiceworks_core`.`dslAccount`.`accountId`                                                            AS `accountId`,
        ifnull(`voiceworks_core`.`dslAccount`.`installAddressId`,
               `voiceworks_core`.`dslAccount`.`addressId`)                                                    AS `addressId`,
        `voiceworks_core`.`dslOrderBbned`.`added`                                                             AS `created_at`,
        `voiceworks_core`.`dslAccount`.`freeze`                                                               AS `freeze`
 from (`voiceworks_core`.`dslOrderBbned`
          join `voiceworks_core`.`dslAccount`
               on ((`voiceworks_core`.`dslAccount`.`id` = `voiceworks_core`.`dslOrderBbned`.`dslaccountId`))))
order by `created_at` desc;

