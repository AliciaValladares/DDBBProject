create view verification_list_orders as
select `bog`.`id`                AS `orderId`,
       `o`.`orderDate`           AS `orderDate`,
       `p`.`name`                AS `product`,
       `i`.`startDate`           AS `startDate`,
       `i`.`quantity`            AS `quantity`,
       `r`.`companyName`         AS `partner`,
       `i`.`endDate`             AS `endDate`,
       `a`.`id`                  AS `accountId`,
       `p`.`id`                  AS `productId`,
       `t`.`id`                  AS `productTypeId`,
       `t`.`name`                AS `productType`,
       `o`.`bundleOrderStatusId` AS `orderStatusId`,
       `s`.`name`                AS `orderStatus`,
       `pc`.`id`                 AS `productCountryId`,
       `pc`.`description`        AS `productCountry`,
       `pc`.`code`               AS `productCountryCode`,
       `p`.`invoiceRuleType`     AS `invoiceRuleType`
from ((((((((`voiceworks_core`.`bundleOrder` `o` join `voiceworks_core`.`bundleOrderGroup` `bog` on ((`bog`.`id` = `o`.`bundleOrderGroupId`))) join `voiceworks_core`.`bundleProductInstance` `i` on ((`i`.`bundleOrderId` = `o`.`id`))) join `voiceworks_core`.`bundleProduct` `p` on ((`p`.`id` = `i`.`bundleProductId`))) join `voiceworks_core`.`bundleProductType` `t` on ((`t`.`id` = `p`.`bundleProductTypeId`))) join `voiceworks_core`.`account` `a` on ((`a`.`id` = `bog`.`accountId`))) join `voiceworks_core`.`account` `r` on ((`r`.`id` = `a`.`parentId`))) join `voiceworks_core`.`bundleOrderStatus` `s` on ((`s`.`id` = `o`.`bundleOrderStatusId`)))
         join `voiceworks_core`.`country` `pc` on ((`pc`.`id` = ifnull(`p`.`countryId`, 1))));

