create view resellerMailMessageView as
(
select `a`.`id`                                        AS `accountId`,
       `vw_msg`.`resellerMailGroupId`                  AS `resellerMailGroupId`,
       `vw_msg`.`code`                                 AS `code`,
       ifnull(`own_msg`.`subject`, `vw_msg`.`subject`) AS `subject`,
       ifnull(`own_msg`.`body`, `vw_msg`.`body`)       AS `body`,
       `vw_msg`.`id`                                   AS `defaultResellerMailMessageId`,
       `own_msg`.`id`                                  AS `resellerResellerMailMessageId`
from ((((`voiceworks_core`.`account` `a` join `voiceworks_core`.`reseller` `r` on ((`a`.`resellerId` = `r`.`id`))) join `voiceworks_core`.`resellerMailMessage` `vw_msg` on ((`vw_msg`.`accountId` = 1))) join `voiceworks_core`.`resellerMailGroup` `rmg` on ((`rmg`.`id` = `vw_msg`.`resellerMailGroupId`)))
         left join `voiceworks_core`.`resellerMailMessage` `own_msg` on (((`own_msg`.`accountId` = `a`.`id`) and
                                                                          (`own_msg`.`resellerMailGroupId` = `vw_msg`.`resellerMailGroupId`) and
                                                                          (`own_msg`.`code` = `vw_msg`.`code`)))));

