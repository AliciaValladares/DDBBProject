create view accountLastDateOrderView as
select `voiceworks_core`.`accountOrderData`.`accountId`      AS `accountId`,
       `voiceworks_core`.`accountOrderData`.`type`           AS `type`,
       max(`voiceworks_core`.`accountOrderData`.`timestamp`) AS `timestamp`
from `voiceworks_core`.`accountOrderData`
group by `voiceworks_core`.`accountOrderData`.`accountId`, `voiceworks_core`.`accountOrderData`.`type`;

