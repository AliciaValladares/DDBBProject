create view ewanLegacyOverviewView as
(select 'ewan'                                                                                                     AS `module`,
        `voiceworks_core`.`ewanSupplier`.`name`                                                                    AS `supplier`,
        `voiceworks_core`.`ewanAccount`.`id`                                                                       AS `id`,
        `voiceworks_core`.`ewanAccount`.`id`                                                                       AS `ewanAccountId`,
        NULL                                                                                                       AS `dslAccountId`,
        `voiceworks_core`.`ewanAccount`.`accountId`                                                                AS `accountId`,
        `voiceworks_core`.`ewanAccount`.`userId`                                                                   AS `userId`,
        ifnull(`voiceworks_core`.`ewanOrder`.`installAddressId`,
               `voiceworks_core`.`ewanOrder`.`requestAddressId`)                                                   AS `addressId`,
        `voiceworks_core`.`ewanAccount`.`created_at`                                                               AS `created_at`,
        `parent`.`companyName`                                                                                     AS `resellerName`,
        if(((`voiceworks_core`.`account`.`companyName` <> '') and
            (`voiceworks_core`.`account`.`companyName` is not null)), `voiceworks_core`.`account`.`companyName`,
           concat_ws(' ', `voiceworks_core`.`account`.`firstName`, `voiceworks_core`.`account`.`prefix`,
                     `voiceworks_core`.`account`.`lastName`))                                                      AS `customerName`
 from ((((`voiceworks_core`.`ewanAccount` left join `voiceworks_core`.`ewanOrder` on ((
         `voiceworks_core`.`ewanOrder`.`ewanAccountId` =
         `voiceworks_core`.`ewanAccount`.`id`))) join `voiceworks_core`.`ewanSupplier` on ((
         `voiceworks_core`.`ewanAccount`.`ewanSupplierId` =
         `voiceworks_core`.`ewanSupplier`.`id`))) join `voiceworks_core`.`account` on ((
         `voiceworks_core`.`account`.`id` = `voiceworks_core`.`ewanAccount`.`accountId`)))
          join `voiceworks_core`.`account` `parent` on ((`parent`.`id` = `voiceworks_core`.`account`.`parentId`))))
union
(select 'dsl'                                                                                                 AS `module`,
        if((count(`voiceworks_core`.`dslOrderTiscali`.`id`) > 0), 'Tiscali',
           'BBned')                                                                                           AS `supplier`,
        `voiceworks_core`.`dslAccount`.`id`                                                                   AS `id`,
        NULL                                                                                                  AS `ewanAccountId`,
        `voiceworks_core`.`dslAccount`.`id`                                                                   AS `dslAccountId`,
        `voiceworks_core`.`dslAccount`.`accountId`                                                            AS `accountId`,
        `voiceworks_core`.`dslAccount`.`userId`                                                               AS `userId`,
        ifnull(`voiceworks_core`.`dslAccount`.`installAddressId`,
               `voiceworks_core`.`dslAccount`.`addressId`)                                                    AS `addressId`,
        `voiceworks_core`.`dslAccount`.`added`                                                                AS `created_at`,
        `parent`.`companyName`                                                                                AS `resellerName`,
        if(((`voiceworks_core`.`account`.`companyName` <> '') and
            (`voiceworks_core`.`account`.`companyName` is not null)), `voiceworks_core`.`account`.`companyName`,
           concat_ws(' ', `voiceworks_core`.`account`.`firstName`, `voiceworks_core`.`account`.`prefix`,
                     `voiceworks_core`.`account`.`lastName`))                                                 AS `customerName`
 from (((`voiceworks_core`.`dslAccount` left join `voiceworks_core`.`dslOrderTiscali` on ((
         `voiceworks_core`.`dslAccount`.`id` =
         `voiceworks_core`.`dslOrderTiscali`.`dslaccountId`))) join `voiceworks_core`.`account` on ((
         `voiceworks_core`.`account`.`id` = `voiceworks_core`.`dslAccount`.`accountId`)))
          join `voiceworks_core`.`account` `parent` on ((`parent`.`id` = `voiceworks_core`.`account`.`parentId`)))
 group by `voiceworks_core`.`dslAccount`.`id`)
order by `created_at` desc;

