create definer = root@localhost trigger acl_user_role_deletes
    after delete
    on aclUserRole
    for each row
BEGIN
  INSERT INTO service_synchronization_logs(urn, entityId) VALUES("urn:user:role-updated", OLD.userId);
END;

