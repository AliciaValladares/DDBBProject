create definer = root@localhost trigger acl_process_role_inserts
    after insert
    on aclProcessRole
    for each row
BEGIN
  INSERT INTO service_synchronization_logs(urn, entityId) VALUES("urn:role:permission-updated", NEW.aclRoleId);
END;

