create definer = root@localhost trigger user_inserts
    after insert
    on user
    for each row
BEGIN
INSERT INTO user_change_log(id, cause) VALUES(NEW.id, "insert");
END;

