create definer = root@localhost trigger account_inserts
    after insert
    on account
    for each row
    INSERT INTO account_change_log(id , cause) VALUES (NEW.id , "insert");

