create view ewanLegacyAccountView as
(select 'ewan'                                                                                                     AS `module`,
        `voiceworks_core`.`ewanSupplier`.`id`                                                                      AS `ewanSupplierId`,
        `voiceworks_core`.`ewanAccount`.`id`                                                                       AS `id`,
        `voiceworks_core`.`ewanAccount`.`id`                                                                       AS `ewanAccountId`,
        NULL                                                                                                       AS `dslAccountId`,
        `voiceworks_core`.`ewanAccount`.`accountId`                                                                AS `accountId`,
        `voiceworks_core`.`ewanAccount`.`userId`                                                                   AS `userId`,
        ifnull(`voiceworks_core`.`ewanOrder`.`installAddressId`,
               `voiceworks_core`.`ewanOrder`.`requestAddressId`)                                                   AS `addressId`,
        `voiceworks_core`.`ewanAccount`.`created_at`                                                               AS `created_at`,
        if(isnull(`foundProduct`.`id`), 0, 1)                                                                      AS `billing`,
        if(((`voiceworks_core`.`account`.`companyName` <> '') and
            (`voiceworks_core`.`account`.`companyName` is not null)), `voiceworks_core`.`account`.`companyName`,
           concat_ws(' ', `voiceworks_core`.`account`.`firstName`, `voiceworks_core`.`account`.`prefix`,
                     `voiceworks_core`.`account`.`lastName`))                                                      AS `customerName`,
        `voiceworks_core`.`ewanAccount`.`reference`                                                                AS `reference`
 from (((((`voiceworks_core`.`ewanAccount` join `voiceworks_core`.`ewanOrder` on ((
         `voiceworks_core`.`ewanOrder`.`ewanAccountId` =
         `voiceworks_core`.`ewanAccount`.`id`))) join `voiceworks_core`.`ewanOrderType` on ((
         (`voiceworks_core`.`ewanOrder`.`ewanOrderTypeId` = `voiceworks_core`.`ewanOrderType`.`id`) and
         (`voiceworks_core`.`ewanOrderType`.`isInitial` = 1)))) left join (((`voiceworks_core`.`ewanAccountVoiceworksProduct` join `voiceworks_core`.`ewanBillingInstance` on ((
         `voiceworks_core`.`ewanBillingInstance`.`ewanAccountVoiceworksProductId` =
         `voiceworks_core`.`ewanAccountVoiceworksProduct`.`id`))) join `voiceworks_core`.`ewanBillingInstanceAccountProducts` on ((
         `voiceworks_core`.`ewanBillingInstanceAccountProducts`.`ewanBillingInstanceId` =
         `voiceworks_core`.`ewanBillingInstance`.`id`))) join `voiceworks_core`.`accountProducts` `foundProduct` on ((
         `foundProduct`.`id` = `voiceworks_core`.`ewanBillingInstanceAccountProducts`.`accountProductId`))) on ((
         `voiceworks_core`.`ewanAccountVoiceworksProduct`.`ewanAccountId` =
         `voiceworks_core`.`ewanAccount`.`id`))) join `voiceworks_core`.`ewanSupplier` on ((
         `voiceworks_core`.`ewanAccount`.`ewanSupplierId` = `voiceworks_core`.`ewanSupplier`.`id`)))
          join `voiceworks_core`.`account`
               on ((`voiceworks_core`.`account`.`id` = `voiceworks_core`.`ewanAccount`.`accountId`)))
 group by `voiceworks_core`.`ewanAccount`.`id`)
union
(select 'dsl'                                                                                                 AS `module`,
        if((count(`voiceworks_core`.`dslOrderTiscali`.`id`) > 0), 2, 1)                                       AS `ewanSupplierId`,
        `voiceworks_core`.`dslAccount`.`id`                                                                   AS `id`,
        NULL                                                                                                  AS `ewanAccountId`,
        `voiceworks_core`.`dslAccount`.`id`                                                                   AS `dslAccountId`,
        `voiceworks_core`.`dslAccount`.`accountId`                                                            AS `accountId`,
        `voiceworks_core`.`dslAccount`.`userId`                                                               AS `userId`,
        ifnull(`voiceworks_core`.`dslAccount`.`installAddressId`,
               `voiceworks_core`.`dslAccount`.`addressId`)                                                    AS `addressId`,
        `voiceworks_core`.`dslAccount`.`added`                                                                AS `created_at`,
        if((count(`voiceworks_core`.`accountProducts`.`id`) > 0), 1, 0)                                       AS `billing`,
        if(((`voiceworks_core`.`account`.`companyName` <> '') and
            (`voiceworks_core`.`account`.`companyName` is not null)), `voiceworks_core`.`account`.`companyName`,
           concat_ws(' ', `voiceworks_core`.`account`.`firstName`, `voiceworks_core`.`account`.`prefix`,
                     `voiceworks_core`.`account`.`lastName`))                                                 AS `customerName`,
        `voiceworks_core`.`dslAccount`.`reference`                                                            AS `reference`
 from (((`voiceworks_core`.`dslAccount` left join `voiceworks_core`.`dslOrderTiscali` on ((
         `voiceworks_core`.`dslAccount`.`id` =
         `voiceworks_core`.`dslOrderTiscali`.`dslaccountId`))) left join (`voiceworks_core`.`dslProductVoiceworksInstance` `foundProduct` join `voiceworks_core`.`accountProducts` on ((
         (`voiceworks_core`.`accountProducts`.`remoteObjectId` = `foundProduct`.`id`) and
         (`voiceworks_core`.`accountProducts`.`productId` = 1658)))) on ((`foundProduct`.`dslAccountId` = `voiceworks_core`.`dslAccount`.`id`)))
          join `voiceworks_core`.`account`
               on ((`voiceworks_core`.`account`.`id` = `voiceworks_core`.`dslAccount`.`accountId`)))
 group by `voiceworks_core`.`dslAccount`.`id`)
order by `created_at` desc;

