create view verification_terminated_billing_active as
select `bpp`.`type` AS `type`, `bog`.`id` AS `id`
from (((`voiceworks_core`.`bundleOrderGroup` `bog` join `voiceworks_core`.`bundleProductPortfolio` `bpp` on ((`bpp`.`id` = `bog`.`bundleProductPortfolioId`))) join `voiceworks_core`.`bundleOrder` `bo` on ((`bo`.`bundleOrderGroupId` = `bog`.`id`)))
         join `voiceworks_core`.`bundleProductInstance` `bpi` on ((`bpi`.`bundleOrderId` = `bo`.`id`)))
where (`bog`.`id` in (select `voiceworks_core`.`bundleOrder`.`bundleOrderGroupId`
                      from `voiceworks_core`.`bundleOrder`
                      where ((`voiceworks_core`.`bundleOrder`.`bundleOrderTypeId` = 3) and
                             (`voiceworks_core`.`bundleOrder`.`readyDate` is not null))) and isnull(`bpi`.`endDate`) and
       (`bpi`.`finterval` > 0))
group by `bog`.`id`;

