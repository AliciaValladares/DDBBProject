create definer = root@localhost trigger user_updates
    after update
    on user
    for each row
BEGIN
INSERT INTO user_change_log(id, cause) VALUES(NEW.id, "update");
END;

