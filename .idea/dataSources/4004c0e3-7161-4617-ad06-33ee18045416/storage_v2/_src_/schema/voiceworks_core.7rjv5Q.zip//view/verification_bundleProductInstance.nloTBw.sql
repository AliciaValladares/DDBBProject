create view verification_bundleProductInstance as
select `a`.`parentId`       AS `parentId`,
       `bpi1`.`startDate`   AS `startDate`,
       `bpi1`.`id`          AS `id_1`,
       `bpi1`.`description` AS `description_1`,
       `bpi1`.`usageType`   AS `usageType_1`,
       `bpi1`.`usageCount`  AS `usageCount_1`,
       `bpi2`.`id`          AS `id_2`,
       `bpi2`.`description` AS `description_2`,
       `bpi2`.`usageType`   AS `usageType_2`,
       `bpi2`.`usageCount`  AS `usageCount_2`
from ((((`voiceworks_core`.`bundleProductInstance` `bpi1` left join `voiceworks_core`.`bundleProductInstance` `bpi2` on ((
        (`bpi1`.`bundleProductId` = `bpi2`.`bundleProductId`) and (`bpi1`.`bundleOrderId` = `bpi2`.`bundleOrderId`) and
        (`bpi1`.`startDate` = `bpi2`.`startDate`) and
        (`bpi1`.`usageType` = `bpi2`.`usageType`)))) join `voiceworks_core`.`bundleOrder` `bo` on ((`bo`.`id` = `bpi1`.`bundleOrderId`))) join `voiceworks_core`.`bundleOrderGroup` `bog` on ((`bog`.`id` = `bo`.`bundleOrderGroupId`)))
         join `voiceworks_core`.`account` `a` on ((`a`.`id` = `bog`.`accountId`)))
where ((`bpi1`.`usageType` is not null) and (`bpi1`.`usageCount` <> `bpi2`.`usageCount`));

