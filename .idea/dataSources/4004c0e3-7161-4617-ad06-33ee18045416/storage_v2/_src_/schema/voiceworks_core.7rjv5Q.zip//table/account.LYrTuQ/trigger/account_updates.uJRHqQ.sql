create definer = root@localhost trigger account_updates
    after update
    on account
    for each row
    INSERT INTO account_change_log(id, cause) VALUES(NEW.id, "update");

