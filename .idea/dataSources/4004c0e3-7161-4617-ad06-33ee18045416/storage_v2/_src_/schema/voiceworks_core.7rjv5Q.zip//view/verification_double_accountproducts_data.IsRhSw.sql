create view verification_double_accountproducts_data as
select count(`bpi`.`id`)                      AS `aantal`,
       `bpi`.`id`                             AS `id`,
       `bpi`.`accountId`                      AS `accountId`,
       `bpi`.`bundleProductId`                AS `bundleProductId`,
       `bpi`.`bundleOrderId`                  AS `bundleOrderId`,
       `bpi`.`stopBundleOrderId`              AS `stopBundleOrderId`,
       `bpi`.`relatedBundleProductInstanceId` AS `relatedBundleProductInstanceId`,
       `bpi`.`startDate`                      AS `startDate`,
       `bpi`.`endDate`                        AS `endDate`,
       `bpi`.`contractEndDate`                AS `contractEndDate`,
       `bpi`.`description`                    AS `description`,
       `bpi`.`price`                          AS `price`,
       `bpi`.`finterval`                      AS `finterval`,
       `bpi`.`fromQuantity`                   AS `fromQuantity`,
       `bpi`.`quantity`                       AS `quantity`,
       `bpi`.`usageType`                      AS `usageType`,
       `bpi`.`usageCount`                     AS `usageCount`,
       `bpi`.`usageDuration`                  AS `usageDuration`
from (`voiceworks_core`.`bundleProductInstance` `bpi`
         join `voiceworks_core`.`bundleProductInstanceAccountProduct` `bpiap`
              on ((`bpiap`.`bundleProductInstanceId` = `bpi`.`id`)))
where (`bpi`.`usageType` = 'd')
group by `bpi`.`id`
having (count(`bpi`.`id`) > 1);

